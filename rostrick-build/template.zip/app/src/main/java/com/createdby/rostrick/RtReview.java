package com.createdby.rostrick;

import android.app.Activity;

/**
 * نسخة فارغة من طلب التقييم داخل التطبيق (لا مكتبة Play Review).
 * عند تفعيل "طلب التقييم" في إعدادات البناء يستبدلها tools/apply_config.py بالنسخة الحقيقية
 * من tools/RtReviewReal.java.txt ويضيف المكتبة.
 */
final class RtReview {
	interface Callback { void done(int id, String json); }

	static final boolean ENABLED = false;

	RtReview(Activity activity, Callback cb) {}
	void request(int id) {}
}
