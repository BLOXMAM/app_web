package com.createdby.rostrick;

import android.app.Activity;

/**
 * نسخة فارغة من طبقة الإشعارات (لا Firebase ولا شيفرة إشعارات داخل التطبيق).
 * عند تفعيل Firebase في إعدادات البناء يستبدلها tools/apply_config.py بالنسخة الحقيقية
 * من tools/RtPushReal.java.txt ويضيف المكتبة وخدمة الرسائل.
 */
final class RtPush {
	interface Callback { void done(int id, String json); }

	static final boolean ENABLED = false;

	RtPush(Activity activity, Callback cb) {}
	void init() {}
	void getToken(int id) {}
	void subscribe(int id, String topic) {}
	void unsubscribe(int id, String topic) {}
	void requestPermission(int id) {}
	void onPermissionResult(boolean granted) {}
	void onResume() {}
	void onPause() {}
	void onDestroy() {}
}
