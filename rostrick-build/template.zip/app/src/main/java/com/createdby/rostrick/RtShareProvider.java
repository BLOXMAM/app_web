package com.createdby.rostrick;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

// RosTrick: مزوّد ملفات بسيط للمشاركة (بدون مكتبات إضافية). يعرض فقط ملفات مجلد cache/rt_share داخل التطبيق.
public class RtShareProvider extends ContentProvider {
	public static String authority(android.content.Context c) { return c.getPackageName() + ".rtshare"; }

	private File resolve(Uri uri) throws FileNotFoundException {
		try {
			String name = uri.getLastPathSegment();
			if (name == null || name.contains("/") || name.contains("..")) throw new FileNotFoundException("bad name");
			File dir = new File(getContext().getCacheDir(), "rt_share");
			File f = new File(dir, name);
			if (!f.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) throw new FileNotFoundException("outside");
			if (!f.isFile()) throw new FileNotFoundException("missing");
			return f;
		} catch (java.io.IOException e) { throw new FileNotFoundException(String.valueOf(e)); }
	}

	@Override public boolean onCreate() { return true; }

	@Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
		return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
	}

	@Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		try {
			File f = resolve(uri);
			MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
			c.addRow(new Object[]{f.getName(), f.length()});
			return c;
		} catch (Exception e) { return null; }
	}

	@Override public String getType(Uri uri) { return null; }
	@Override public Uri insert(Uri uri, ContentValues values) { return null; }
	@Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
	@Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
