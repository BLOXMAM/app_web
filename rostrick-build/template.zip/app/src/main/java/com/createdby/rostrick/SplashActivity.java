package com.createdby.rostrick;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import com.createdby.rostrick.databinding.*;
import com.scottyab.rootbeer.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SplashActivity extends Activity {
	
	private SplashBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = SplashBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	// يفتح الرابط في المتصفح الافتراضي بدون المرور بتطبيقنا (لتجنّب الحلقة)
	private boolean rtOpenInBrowser(android.net.Uri uri) {
		try {
			android.content.Intent view = new android.content.Intent(android.content.Intent.ACTION_VIEW, uri);
			view.addCategory(android.content.Intent.CATEGORY_BROWSABLE);
			view.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
			view.setSelector(android.content.Intent.makeMainSelectorActivity(android.content.Intent.ACTION_MAIN, android.content.Intent.CATEGORY_APP_BROWSER));
			startActivity(view);
			return true;
		} catch (Throwable t1) {
			try {
				android.content.Intent v2 = new android.content.Intent(android.content.Intent.ACTION_VIEW, uri);
				android.content.Intent ch = android.content.Intent.createChooser(v2, null);
				if (android.os.Build.VERSION.SDK_INT >= 24) ch.putExtra(android.content.Intent.EXTRA_EXCLUDE_COMPONENTS, new android.content.ComponentName[] { new android.content.ComponentName(this, SplashActivity.class) });
				ch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(ch);
				return true;
			} catch (Throwable t2) { return false; }
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		// RosTrick: رابط https لملف ثابت (css/js/صورة...) لا يخص التطبيق -> نفتحه في المتصفح بدل التطبيق
		try {
			android.net.Uri rtU = getIntent() != null ? getIntent().getData() : null;
			if (rtU != null && rtU.getScheme() != null && rtU.getScheme().toLowerCase(java.util.Locale.ROOT).startsWith("http")) {
				String rtLast = rtU.getLastPathSegment();
				if (rtLast != null && rtLast.lastIndexOf('.') > 0) {
					String rtExt = rtLast.substring(rtLast.lastIndexOf('.') + 1).toLowerCase(java.util.Locale.ROOT);
					if (!rtExt.equals("html") && !rtExt.equals("htm")) {
						if (rtOpenInBrowser(rtU)) { finish(); return; }
					}
				}
			}
		} catch (Throwable ignored) {}
		com.scottyab.rootbeer.RootBeer rootBeer = new com.scottyab.rootbeer.RootBeer(SplashActivity.this);
		
		if (rootBeer.isRooted()) {
			// تم اكتشاف روت، إيقاف التطبيق تماماً
			new android.app.AlertDialog.Builder(SplashActivity.this)
			.setTitle(RtI18n.t("تنبيه أمني ⚠️", "Security alert ⚠️"))
			.setMessage(RtI18n.t("عذراً، لا يمكن تشغيل التطبيق على أجهزة تحتوي على صلاحيات الروت لأسباب تتعلق بالأمان.", "Sorry, the app cannot run on rooted devices for security reasons."))
			.setCancelable(false)
			.setPositiveButton(RtI18n.t("إغلاق التطبيق", "Close app"), new android.content.DialogInterface.OnClickListener() {
				@Override
				public void onClick(android.content.DialogInterface dialog, int which) {
					finishAffinity(); // إغلاق التطبيق من الجذور
				}
			})
			.show();
			return; // إيقاف إكمال أي كود تالٍ في الـ Splash
		}
		
		// إذا كان الجهاز سليماً، انتقل إلى MainActivity بشكل طبيعي
		android.content.Intent intent = new android.content.Intent(SplashActivity.this, MainActivity.class);
		// RosTrick: إشعار Firebase فيه صفحة مطلوبة (rt_page) -> نمرّرها لـ MainActivity لتفتحها
		try {
			String rtPage = getIntent() != null ? getIntent().getStringExtra("rt_page") : null;
			if (rtPage != null && rtPage.length() > 0) intent.putExtra("rt_page", rtPage);
		} catch (Throwable ignored) {}
		// RosTrick: رابط عميق (Deep Link) فُتح به التطبيق -> نمرّره لـ MainActivity
		try {
			android.net.Uri rtData = getIntent() != null ? getIntent().getData() : null;
			if (rtData != null) {
				String rtLink = rtData.toString();
				if (rtLink.length() > 0 && rtLink.length() <= 2048) intent.putExtra("rt_link", rtLink);
			}
		} catch (Throwable ignored) {}
		startActivity(intent);
		finish();
	}
	
}
