/* RosTrick — واجهات المتصفح القياسية لصفحات التطبيق (clipboard, wakeLock, Notification, getBattery, share, contacts, serviceWorker).
   تُحقن تلقائياً في كل صفحة من MainActivity. لا تعدّل هذا الملف؛ أسماء الواجهات هي الأسماء القياسية للمتصفح. */
(function () {
  try {
    if (window.__rtWAv) return;
    var B = window.RosTrickWebApiBridge;
    if (!B) return;
    window.__rtWAv = 1;

    var pend = {}, n = 0, evh = {};
    window.__rtWA = function (id, s) {
      var r = pend[id]; if (!r) return; delete pend[id];
      var o; try { o = JSON.parse(s); } catch (e) { o = { ok: false, error: 'bad response' }; }
      r(o);
    };
    window.__rtWAEv = function (name, s) {
      var o; try { o = JSON.parse(s); } catch (e) { o = {}; }
      (evh[name] || []).forEach(function (f) { try { f(o); } catch (e) {} });
    };
    function onEv(name, f) { (evh[name] = evh[name] || []).push(f); }
    function call(fn) {
      var a = [].slice.call(arguments, 1);
      return new Promise(function (res) {
        var id = ++n; pend[id] = res;
        try { B[fn].apply(B, [id].concat(a)); } catch (e) { delete pend[id]; res({ ok: false, error: String(e) }); }
      });
    }
    function def(obj, prop, val) {
      try { Object.defineProperty(obj, prop, { configurable: true, enumerable: true, writable: true, value: val }); }
      catch (e) { try { obj[prop] = val; } catch (_) {} }
    }
    function fail(o, name) { return new DOMException((o && o.error) || 'failed', name || 'NotAllowedError'); }

    /* ---------- navigator.clipboard ---------- */
    if (typeof window.ClipboardItem === 'undefined') {
      var CI = function (items) {
        this._items = items || {};
        this.types = Object.keys(this._items);
        this.presentationStyle = 'unspecified';
      };
      CI.prototype.getType = function (t) {
        var self = this;
        if (!(t in self._items)) return Promise.reject(new DOMException('type not found', 'NotFoundError'));
        return Promise.resolve(self._items[t]).then(function (b) { return b instanceof Blob ? b : new Blob([String(b)], { type: t }); });
      };
      CI.supports = function (t) { return t === 'text/plain'; };
      def(window, 'ClipboardItem', CI);
    }
    var clip = {
      writeText: function (t) {
        return call('clipboardWrite', String(t == null ? '' : t)).then(function (o) { if (!o.ok) throw fail(o); });
      },
      readText: function () {
        return call('clipboardRead').then(function (o) { if (!o.ok) throw fail(o); return o.text || ''; });
      },
      write: function (items) {
        var it = items && items[0];
        if (!it || it.types.indexOf('text/plain') < 0) return Promise.reject(new DOMException('only text/plain is supported', 'NotAllowedError'));
        return it.getType('text/plain').then(function (b) { return b.text(); }).then(function (t) { return clip.writeText(t); });
      },
      read: function () {
        return clip.readText().then(function (t) { return [new window.ClipboardItem({ 'text/plain': new Blob([t], { type: 'text/plain' }) })]; });
      },
      addEventListener: function () {}, removeEventListener: function () {}
    };
    def(navigator, 'clipboard', clip);

    /* ---------- navigator.wakeLock ---------- */
    var locks = 0;
    try { B.wakeLockSet(false); } catch (e) {}
    def(navigator, 'wakeLock', {
      request: function (type) {
        if (type && type !== 'screen') return Promise.reject(new TypeError("The provided value '" + type + "' is not a valid enum value of type WakeLockType."));
        var s = new EventTarget();
        s.type = 'screen'; s.released = false; s.onrelease = null;
        s.release = function () {
          if (s.released) return Promise.resolve();
          s.released = true; locks = Math.max(0, locks - 1);
          if (!locks) { try { B.wakeLockSet(false); } catch (e) {} }
          try { if (typeof s.onrelease === 'function') s.onrelease(new Event('release')); } catch (e) {}
          try { s.dispatchEvent(new Event('release')); } catch (e) {}
          return Promise.resolve();
        };
        locks++;
        try { B.wakeLockSet(true); } catch (e) {}
        return Promise.resolve(s);
      }
    });

    /* ---------- window.Notification ---------- */
    var reg = {}, nn = 0;
    function NotificationShim(title, opts) {
      if (!(this instanceof NotificationShim)) throw new TypeError("Failed to construct 'Notification': Please use the 'new' operator, this DOM object constructor cannot be called as a function.");
      opts = opts || {};
      var self = this, et = new EventTarget();
      self.title = String(title); self.body = opts.body == null ? '' : String(opts.body);
      self.tag = opts.tag ? String(opts.tag) : ('rt' + (++nn)); self.data = opts.data === undefined ? null : opts.data;
      self.icon = opts.icon || ''; self.lang = opts.lang || ''; self.dir = opts.dir || 'auto';
      self.silent = !!opts.silent; self.onclick = self.onshow = self.onclose = self.onerror = null;
      self.addEventListener = function (t, f, o) { et.addEventListener(t, f, o); };
      self.removeEventListener = function (t, f, o) { et.removeEventListener(t, f, o); };
      self.dispatchEvent = function (e) { return et.dispatchEvent(e); };
      self._fire = function (type) {
        var e = new Event(type);
        try { var h = self['on' + type]; if (typeof h === 'function') h.call(self, e); } catch (x) {}
        try { et.dispatchEvent(e); } catch (x) {}
      };
      self.close = function () { try { B.notifClose(self.tag); } catch (x) {} self._fire('close'); };
      reg[self.tag] = self;
      var ok = false;
      try { ok = B.notifPermission() === 'granted' && B.notifShow(self.tag, self.title, self.body); } catch (x) {}
      setTimeout(function () { self._fire(ok ? 'show' : 'error'); }, 0);
    }
    Object.defineProperty(NotificationShim, 'permission', { get: function () { try { return B.notifPermission(); } catch (e) { return 'denied'; } } });
    NotificationShim.maxActions = 0;
    NotificationShim.requestPermission = function (cb) {
      return call('notifRequest').then(function (o) {
        var p = o.permission || 'denied';
        if (typeof cb === 'function') { try { cb(p); } catch (e) {} }
        return p;
      });
    };
    def(window, 'Notification', NotificationShim);
    onEv('notifclick', function (o) {
      var inst = reg[o.tag]; if (!inst) return;
      inst._fire('click');
    });

    /* ---------- navigator.serviceWorker (واجهة متوافقة بلا اعتراض للطلبات) ---------- */
    var swReg = {
      scope: (function () { try { return location.href.replace(/[^\/]*$/, ''); } catch (e) { return ''; } })(),
      active: { state: 'activated', scriptURL: '' }, installing: null, waiting: null, navigationPreload: undefined,
      update: function () { return Promise.resolve(swReg); },
      unregister: function () { return Promise.resolve(true); },
      showNotification: function (title, opts) { new NotificationShim(title, opts); return Promise.resolve(); },
      getNotifications: function () { return Promise.resolve([]); },
      pushManager: {
        getSubscription: function () { return Promise.resolve(null); },
        permissionState: function () { return Promise.resolve(NotificationShim.permission === 'granted' ? 'granted' : (NotificationShim.permission === 'denied' ? 'denied' : 'prompt')); },
        subscribe: function () { return Promise.reject(new DOMException('Push subscription is not supported here. Use RosTrickPush.', 'NotSupportedError')); }
      },
      addEventListener: function () {}, removeEventListener: function () {}
    };
    def(navigator, 'serviceWorker', {
      controller: null,
      ready: Promise.resolve(swReg),
      register: function (url) { try { swReg.active.scriptURL = String(url); } catch (e) {} return Promise.resolve(swReg); },
      getRegistration: function () { return Promise.resolve(swReg); },
      getRegistrations: function () { return Promise.resolve([swReg]); },
      startMessages: function () {},
      addEventListener: function () {}, removeEventListener: function () {}
    });

    /* ---------- navigator.getBattery() ---------- */
    var batt = null;
    function battUpdate(o) {
      if (!batt || !o || o.ok === false) return;
      var lv = typeof o.level === 'number' ? o.level : batt.level;
      var ct = (typeof o.chargingTime === 'number' && o.chargingTime >= 0) ? o.chargingTime : Infinity;
      var chg = !!o.charging;
      var ch = [];
      if (lv !== batt.level) ch.push('levelchange');
      if (chg !== batt.charging) ch.push('chargingchange');
      if (ct !== batt.chargingTime) ch.push('chargingtimechange');
      batt.level = lv; batt.charging = chg; batt.chargingTime = ct; batt.dischargingTime = Infinity;
      ch.forEach(function (t) {
        var e = new Event(t);
        try { if (typeof batt['on' + t] === 'function') batt['on' + t](e); } catch (x) {}
        try { batt.dispatchEvent(e); } catch (x) {}
      });
    }
    def(navigator, 'getBattery', function () {
      if (!batt) {
        var o = {};
        try { o = JSON.parse(B.batteryStart()); } catch (e) {}
        batt = new EventTarget();
        batt.level = 1; batt.charging = true; batt.chargingTime = 0; batt.dischargingTime = Infinity;
        batt.onlevelchange = batt.onchargingchange = batt.onchargingtimechange = batt.ondischargingtimechange = null;
        if (o && o.ok) {
          batt.level = o.level; batt.charging = !!o.charging;
          batt.chargingTime = (typeof o.chargingTime === 'number' && o.chargingTime >= 0) ? o.chargingTime : (o.charging ? Infinity : Infinity);
        }
        onEv('battery', battUpdate);
      }
      return Promise.resolve(batt);
    });

    /* ---------- navigator.share / canShare (عبر RosTrickShare) ---------- */
    var S = window.RosTrickShare;
    if (S && S.available) {
      var hasData = function (d) {
        return !!d && (d.title != null || d.text != null || d.url != null || (d.files && d.files.length));
      };
      def(navigator, 'canShare', function (d) {
        if (!hasData(d)) return false;
        if (d.files) { for (var i = 0; i < d.files.length; i++) { if (!(d.files[i] instanceof Blob)) return false; } }
        return true;
      });
      def(navigator, 'share', function (d) {
        if (!hasData(d)) return Promise.reject(new TypeError("Failed to execute 'share' on 'Navigator': Invalid share data"));
        var base = { title: d.title == null ? '' : String(d.title), text: d.text == null ? '' : String(d.text), url: d.url == null ? '' : String(d.url) };
        var go = function (extra) {
          for (var k in extra) base[k] = extra[k];
          return S.share(base).then(function (ok) { if (!ok) throw new DOMException('Share failed', 'NotAllowedError'); });
        };
        var f = d.files && d.files[0];
        if (!f) return go({});
        return new Promise(function (res, rej) {
          var fr = new FileReader();
          fr.onload = function () { res(String(fr.result)); };
          fr.onerror = function () { rej(new DOMException('Cannot read file', 'NotReadableError')); };
          fr.readAsDataURL(f);
        }).then(function (data) { return go({ file: data, fileName: f.name || 'share', mime: f.type || '' }); });
      });
    }

    /* ---------- navigator.contacts ---------- */
    def(navigator, 'contacts', {
      getProperties: function () { return Promise.resolve(['name', 'tel', 'email']); },
      select: function (props, opts) {
        if (!Array.isArray(props) || !props.length) return Promise.reject(new TypeError("Failed to execute 'select' on 'ContactsManager': The properties argument must not be empty."));
        var okp = ['name', 'tel', 'email'];
        for (var i = 0; i < props.length; i++) { if (okp.indexOf(props[i]) < 0) return Promise.reject(new TypeError("The provided value '" + props[i] + "' is not a valid enum value of type ContactProperty.")); }
        return call('contactsSelect', props.join(',')).then(function (o) {
          if (!o.ok) throw fail(o, 'InvalidStateError');
          return (o.contacts || []).map(function (c) {
            var r = {};
            props.forEach(function (p) { r[p] = c[p] || []; });
            return r;
          });
        });
      }
    });
  } catch (e) {}
})();
